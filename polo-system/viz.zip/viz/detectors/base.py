from typing import List, Dict, Any

def detect(text: str, mentions: Dict[str, Dict[str, float]]) -> List[Dict[str, Any]]:
    """각 디텍터는 이 함수를 구현합니다."""
    return []